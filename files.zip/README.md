# Daily Attendance Register

A single-page attendance app: sign in with Google, tap **Check In Now**, and your
name gets stamped into today's ledger. Built with Firebase Auth + Firestore.
No build step, no env vars to fill in — the Firebase config is already wired
into `index.html`, so it deploys as-is.

## 1. Deploy to Vercel (no input needed)

**Option A — CLI (fastest):**
```bash
npm i -g vercel
cd attendance-app
vercel --prod
```
Just accept the defaults when prompted (or add `--yes` to skip all prompts).

**Option B — Drag and drop:**
Go to https://vercel.com/new, drag this folder onto the page, click Deploy.

**Option C — GitHub:**
Push this folder to a GitHub repo, then "Import Project" on vercel.com and
pick the repo. Every push redeploys automatically.

No environment variables are required — everything runs client-side with the
config already in `index.html`.

## 2. One-time Firebase setup (do this before sharing the link)

Firebase client API keys are meant to be public (this is normal — Firebase
security is enforced by rules, not by hiding the key), but you still need to:

1. **Enable Google sign-in**: Firebase Console → Build → Authentication →
   Sign-in method → enable **Google**.
2. **Add your Vercel domain**: Authentication → Settings → Authorized domains
   → add `your-project.vercel.app` (and any custom domain you use).
3. **Create the Firestore database**: Build → Firestore Database → Create
   database (production mode is fine).
4. **Apply the security rules** in `firestore.rules` (included in this
   folder): Firestore Database → Rules → paste the contents → Publish.
   This locks it down so a signed-in user can only ever create *their own*
   check-in for *today*, and can't edit or delete entries — so nobody can
   forge or erase attendance.

Skip step 4 and anyone with the (public) config could write arbitrary data
to your database, so don't skip it.

## What's in this folder

- `index.html` — the whole app (HTML/CSS/JS, no framework, no build step)
- `vercel.json` — static hosting config
- `firestore.rules` — copy-paste into the Firebase console

## How it works

- Google sign-in via Firebase Auth (popup).
- Each check-in writes one document to `attendance/{YYYY-MM-DD}_{uid}` —
  the ID itself prevents duplicate check-ins for the same person on the
  same day.
- The ledger view listens live (`onSnapshot`) to all of today's entries, so
  everyone signed in sees new check-ins appear in real time.
- Attendance is scoped by calendar day using a `dateKey` field, so history
  naturally accumulates day over day with no cleanup needed.
